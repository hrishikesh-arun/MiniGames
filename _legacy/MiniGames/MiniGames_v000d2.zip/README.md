# MiniGames

 MiniGames is a games platform where you can play minigames such as Wordle, Nim etc.
 
 It is programmed in Java

 It utilises the package myLib for file and input control and runMiniGames.bat for the execution of code.

## MiniGames - Roadmap

### Roadmap (# Means Complete)

- **v0.0.0d1**  : Introduction of MiniGames (#)
- **v0.0.0d2**  : Introduction of Nim Game (#)

- More Updates Coming soon!

- _**v1.0.0**_  : Final Game<br>